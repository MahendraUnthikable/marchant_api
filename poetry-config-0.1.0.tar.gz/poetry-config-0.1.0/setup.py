# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry_config']

package_data = \
{'': ['*']}

install_requires = \
['Django>=4.0.5,<5.0.0',
 'black>=22.3.0,<23.0.0',
 'djangorestframework>=3.13.1,<4.0.0',
 'flake8>=4.0.1,<5.0.0']

setup_kwargs = {
    'name': 'poetry-config',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'MahendraUnthinkable',
    'author_email': 'mahendra.singh@unthinkable.co',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
